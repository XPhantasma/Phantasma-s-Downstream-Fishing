import pygame
import os
import random
import fish
import player


#-----------------------------------------------------------------------------------------------------------------------

class Main:
    def __init__(self):
        pygame.init()
        self.screen_x = 460
        self.screen_y = 640
        self.screen = pygame.display.set_mode((self.screen_x, self.screen_y))
        self.clock = pygame.time.Clock()
        self.running = True

        self.background = pygame.image.load(os.path.join("Backgrounds", "BackgroundGameplay.png"))
        self.offswitch_image = pygame.image.load(os.path.join("Sprites", "OffSwitchImage.png"))

        font_list = pygame.font.get_fonts()
        self.text = pygame.font.SysFont(font_list[0], 20, False, False)
        self.font_color = (0, 0, 0)

        self.titleScreen = True
        self.gameplay = False
        self.gameOverCredits = False

        self.timed_interval = 30
        self.timer = 0
        self.bad_fish_rng = 3

        self.bad_fish_limit = 3

        self.counter_fish_caught = 0
        self.counter_fish_missed = 0
        self.counter_bad_fish_caught = 0
        self.counter_score = 0

        self.player_group = pygame.sprite.Group()
        self.player = player.Player(0,0)
        self.player_created = False


        self.fish_group = pygame.sprite.Group()
        self.fish = fish.Fish(0,0, 0)

    def draw_text(self, text, font, text_col, x, y):
        img = font.render(text, True, text_col)
        self.screen.blit(img, (x, y))

    def titlescreen_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            if event.type == pygame.KEYDOWN:
                self.titleScreen = False
                self.gameplay = True

    def gameplay_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            # Implement switch sequence between gameplay and menu
            if not self.player_created:
                self.player = player.Player(200, 550)
                self.player_group.add(self.player_group, self.player)
                self.player_created = True

        self.timer += 1
        if self.timer >= self.timed_interval:
           self.timer = 0
           self.fish = fish.Fish(random.randint(110,300), -100, random.randint(0, 3))
           self.fish_group.add(self.fish_group, self.fish)
           if random.randint(0,3) == 3:
               self.fish = fish.Fish(random.randint(110, 300), -100, 4)
               self.fish_group.add(self.fish_group, self.fish)

        mouse_pos = pygame.mouse.get_pos()
        mouse_pos_x = mouse_pos[0]
        self.player.move_to_mouse_POS(mouse_pos_x)

        for the_fish in self.fish_group:
            the_fish.fish_move()
            if pygame.sprite.spritecollideany(self.player, self.fish_group, None):
                if the_fish.spawntype == 4:
                    the_fish.kill()
                    self.counter_bad_fish_caught += 1
                    if self.counter_bad_fish_caught == self.bad_fish_limit:
                        self.gameplay = False
                        self.gameOverCredits = True

                else:
                    self.counter_score += the_fish.fish_scorepoint
                    the_fish.kill()
                    self.counter_fish_caught += 1

            if the_fish.rect.y > self.screen_y:
                if the_fish.spawntype == 4:
                    the_fish.kill()
                else:
                    the_fish.kill()
                    self.counter_fish_missed += 1

    def gameover_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            if event.type == pygame.KEYDOWN:
                self.running = False

    def game_states(self):
        if self.titleScreen:
            self.titlescreen_event()
        elif self.gameplay:
            self.gameplay_event()
        elif self.gameOverCredits:
            self.gameover_event()

    def game_rendering(self):

        self.screen.blit(self.background, (0,0))

        if self.titleScreen:
            self.draw_text("Phantasma's Downstream Fishing", self.text, self.font_color, 100, 50)
            self.draw_text("Press any key to start game", self.text, self.font_color, 100, 100)
            self.draw_text("Controls: Mouse movement to move fisherman", self.text, self.font_color, 100, 150)
            self.draw_text("Clicking is used for toggling", self.text, self.font_color, 100, 200)
            self.draw_text("sound and music(Unfinished)", self.text, self.font_color, 100,240)
            self.draw_text("Version 1.0", self.text, self.font_color, 20,600)

        if self.gameplay:
            pygame.draw.line(self.screen,
                             (0,0,255),
                             (90, 0),
                             (90, 640),
                             1)

            pygame.draw.line(self.screen,
                             (0, 0, 255),
                             (320, 0),
                             (320, 640),
                             1)

            self.player_group.draw(self.screen)
            self.fish_group.draw(self.screen)

            self.draw_text("Sound", self.text, self.font_color, 330, 50)
            self.draw_text("Music", self.text, self.font_color, 400, 50)
            self.draw_text("Fish Caught: " + str(int(self.counter_fish_caught)), self.text, self.font_color, 330, 100)
            self.draw_text("Fish Missed: " + str(int(self.counter_fish_missed)), self.text, self.font_color, 330, 150)
            self.draw_text("Bad Fish: " + str(int(self.counter_bad_fish_caught)) +"/" + str(int(self.bad_fish_limit)), self.text, self.font_color, 330, 200)
            self.draw_text("Score", self.text, self.font_color, 330, 250)
            self.draw_text((str(int(self.counter_score))),  self.text, self.font_color, 330, 280)

        if self.gameOverCredits:
            self.draw_text("Game Over", self.text, self.font_color, 100, 50)
            self.draw_text("Too many bad fish caught", self.text, self.font_color, 100, 100)
            self.draw_text("Score : " + str(int(self.counter_score)), self.text, self.font_color, 100, 150)
            self.draw_text("Press any key to exit", self.text, self.font_color, 100, 200)

        pygame.display.flip()
        self.clock.tick(60)  # limits FPS to 60

    def run(self):
        self.game_states()
        self.game_rendering()

    pygame.quit()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main = Main()
    while main.running:
        main.run()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
