import pygame
import os # Not in use...YET



class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Sprites", "PlayerFisherman.png"))
        self.image.set_colorkey((255,255,255))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def move_to_mouse_POS(self, mouse_x_pos):
        if self.rect.x < 90 or self.rect.x > 320:
            return

        if mouse_x_pos > self.rect.x + 20:
            for x in range(5,0,-1):
                if (mouse_x_pos - (self.rect.x + 20)) > (x + 1):
                    self.rect.x += x
                    if self.rect.x > (320 - 40):
                        self.rect.x -= x
                    break


        elif mouse_x_pos < self.rect.x + 20:
            for x in range(5,0, -1):
                if (mouse_x_pos - (self.rect.x + 20)) < -(x + 1):
                    self.rect.x -= x
                    if self.rect.x < 91:
                        self.rect.x += x
                    break
        else:
            pass

