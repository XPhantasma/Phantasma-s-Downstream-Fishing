import pygame
import os # Not in use...YET

# 5 different classes of fish

class Fish(pygame.sprite.Sprite):
    def __init__(self, x, y, spawntype):
        pygame.sprite.Sprite.__init__(self)
        self.spawntype = spawntype
        if self.spawntype == 0:
            self.image = pygame.image.load(os.path.join("Sprites", "FishBlue.png"))
            self.image.set_colorkey((255, 255, 255))
            self.fish_scorepoint = 10
        if self.spawntype == 1:
            self.image = pygame.image.load(os.path.join("Sprites", "FishGreen.png"))
            self.image.set_colorkey((255, 255, 255))
            self.fish_scorepoint = 25
        if self.spawntype == 2:
            self.image = pygame.image.load(os.path.join("Sprites", "FishPurple.png"))
            self.image.set_colorkey((255, 255, 255))
            self.fish_scorepoint = 50
        if self.spawntype == 3:
            self.image = pygame.image.load(os.path.join("Sprites", "FishYellow.png"))
            self.image.set_colorkey((255, 255, 255))
            self.fish_scorepoint = 100
        if self.spawntype == 4:
            self.image = pygame.image.load(os.path.join("Sprites", "FishRed.png"))
            self.image.set_colorkey((255, 255, 255))
            self.fish_scorepoint = 0
        #self.image = pygame.Surface((20, 40))
        #self.image.fill((255, 255, 0))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def fish_move(self):
        self.rect.y += 5

# This segment DNF
def spawn_sequence_fish(number):
    if number == 0:
        # Random Spawn location in sequence
        pass
    if number == 1:
        # Zig-Zag spawn from right edge to left edge and back
        pass
    if number == 2:
        # Zig-Zag spawn from left edge to right edge and back
        pass
    if number == 3:
        # Curved back and forth starting from right edge
        pass
    if number == 4:
        pass
    if number == 5:
        pass
